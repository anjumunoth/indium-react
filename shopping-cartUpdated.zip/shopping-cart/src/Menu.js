import React from 'react'
import "./Menu.css"
import {Link} from 'react-router-dom'

class Menu extends React.Component
{
    render()
    {
        return(
            <div>
              
                <ul className="ulStyle bg-warning  ">
                    <li className="liStyle p-2 m-2 fs-3 ">
                        <Link to="/products">Products</Link>
                    </li>
                    <li className="liStyle p-2 m-2 fs-3">
                        <Link to="/employee">Employee</Link>
                    </li>
                    <li className="liStyle p-2 m-2 fs-3">
                        <Link to="/cart">Cart</Link>
                    </li>
                    <li className="liStyle p-2 m-2 fs-3">
                        <Link to="/login">Login</Link>
                    </li>
                    <li className="liStyle p-2 m-2 fs-3">
                        <Link to="/register">Register</Link>
                    </li>
                </ul>
            </div>
        )
    }
}

export default Menu