// class component
import React from "react";
import AddEmployee from "./AddEmployee";
import "./Employee.css"
import EditEmployee from "./EditEmployee"

class Employee extends React.Component
{
    empId=101;
    constructor()
    {
        // called implicitly whenever an instance of class is going to be created
        super();//call to base class constructor. first stat
        this.cancelNewEmployeeEventHandler=this.cancelNewEmployeeEventHandler.bind(this);
        this.state={showAddEmployee:false,showEditEmployee:false,selectedEmp:{},
        empArr:[
            {empId:101,empName:"Sara",salary:1009,location:"CHN"},
            {empId:102,empName:"Tara",salary:4323,location:"BLR"},
            {empId:103,empName:"Lara",salary:432,location:"BLR"},
            {empId:104,empName:"Piyush",salary:44,location:"BLR"},
            {empId:105,empName:"Shiva",salary:455,location:"CHN"}
        ]}
    }
    addNewEmployeeEventHandler=()=>{
        this.setState({showAddEmployee:true})
        // call the render method again
    }
    
    cancelNewEmployeeEventHandler()
    {
        this.setState({showAddEmployee:false})
    }
    editEventHandler=(obj) => {
        console.log("Edit item details",obj)
        this.setState({showEditEmployee:true,selectedEmp:obj})
    }
    deleteEventHandler=(empId)=>{
        var pos=this.state.empArr.findIndex(item => item.empId === empId)
        if(pos >=0)
        {
            var tempArr=[...this.state.empArr];
            tempArr.splice(pos,1);
            this.setState({empArr:tempArr})
        }
    }
    editConfirmEventHandler=(p1)=>{
        alert("edit confirm event triggered")
        console.log("Edited data in Emp Component",p1)
        //var tempArr=this.state.empArr;// ref
        var tempArr=[...this.state.empArr];//copy
        var pos=tempArr.findIndex(item =>item.empId === p1.empId)
        if(pos >=0)
        {
            tempArr[pos]=p1;
        }
        this.setState({empArr:tempArr,showEditEmployee:false});

        
    }
    addConfirmEventHandler =(obj)=>{

        var tempArr=[...this.state.empArr,obj]
        var pos=tempArr.findIndex(item => item.empId == obj.empId)
        if(pos >=0)
        {
            alert("Emp Id already exists");
            this.setState({showAddEmployee:false});
        }
        else
        {
            this.setState({empArr:tempArr,showAddEmployee:false});      
        }
    }
    render()
    {
        // render called implicitly
        // after the constructor
        // lifecycle method
        var username =sessionStorage.getItem("username")?sessionStorage.getItem("username"):"Stranger"
        var password =localStorage.getItem("password")?localStorage.getItem("password"):"Guest"
        var trArr=this.state.empArr.map(item =>{
            return (
                <tr key={item.empId}>
                    <td>{item.empId}</td>
                    <td>{item.empName}</td>
                    <td>{item.salary}</td>
                    <td>{item.location}</td>
                    <td>
                        <button  
                        className="btn btn-success m-2" onClick={this.editEventHandler.bind(this,item)}>
                         
                            <i className="bi bi-pencil-fill"></i>
                        </button>
                        <button 
                        className="btn btn-danger m-2" onClick={this.deleteEventHandler.bind(this,item.empId)}>
                            <i className="bi bi-person-x-fill"></i>
                            </button>
                    </td>
                </tr>
            )
        })
        var h1BGColor={backgroundColor:"cyan",color:"blue"}
        // return the virtual DOM
        return(
            <div>
               <h1 style={h1BGColor} className="text-center h1Style">Employee Details</h1>
               <h2> Welcome {username}</h2>
               <h2> Password {password}</h2>
                <table className="table bg-info text-primary text-center">
                    <thead>
                        <tr>
                            <th>Employee Id</th>
                            <th>Employee Name</th>
                            <th>Salary</th>
                            <th>Location</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {trArr}
                    </tbody>
                </table>
                <input type="button" value="Add new Employee" 
                className="btn btn-primary m-2" 
                onClick={this.addNewEmployeeEventHandler}/>
                
                <input type="button" value ="Cancel new Employee"
                className="btn btn-primary m-2"
                onClick={this.cancelNewEmployeeEventHandler} />

                {this.state.showAddEmployee && <AddEmployee onAddConfirm={this.addConfirmEventHandler} ></AddEmployee>}
                {this.state.showEditEmployee && <EditEmployee onEditConfirm={this.editConfirmEventHandler} selectedEmp={this.state.selectedEmp} ></EditEmployee>}
            </div>
        )
    }
}
export default Employee;

/*
button
event and event handler
def of event handler -- in the same component where button is rendered
when is event handler excuted -- event is triggered
*/
