import React from 'react'

function Footer(props)
{
    return(
        <React.Fragment>
            <h1>Footer Component</h1>
        </React.Fragment>
    )
}
export default Footer