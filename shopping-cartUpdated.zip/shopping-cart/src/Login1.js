// finish the validations
import React from 'react'

class Login extends React.Component
{
    render()
    {
        return(
            <React.Fragment>
                <div>
                    <form>
                        <div>
                        <div>
                                <label>Username</label>
                                <input type="text" required className="form-control m-2"
                                ref={this.usernameRef} />
                            </div>
                            <div>
                                <label>Password</label>
                                <input type="password" required className="form-control m-2"
                                ref={this.passwordRef}/>
                            </div>
                            <div>
                                <input type="checkbox" checked />
                                Rememeber me
                            </div>
                            <div>
                            <input type="button" value="Login" className="btn btn-success m-2"/>
                            <input type="reset" value="Cancel" className="btn btn-success m-2"/>
                            </div>
                            <div>
                                <a href="#"> New User?Sign In</a>
                            </div>
                            
                        </div>
                    </form>
                </div>
            </React.Fragment>
        )
    }
}
export default Login
