import React from 'react'

class Register extends React.Component {
    constructor() {
        super()
        this.state = {
            countryName: ["Select","India", "Australia", "Malaysia", "Singapore", "Phillipines"]
        }
        this.usernameRef=React.createRef();
        this.passwordRef=React.createRef();
        this.countryRef=React.createRef();
    }
    registerEventHandler=(event)=>{
        event.preventDefault();
      /*
      1. password and confirm password should match
      2. password should be a strong password
      */
        
     // once the validations are successful
        sessionStorage.setItem("username",this.usernameRef.current.value);
        localStorage.setItem("password",this.passwordRef.current.value);
        console.log(this.countryRef)
        if(this.countryRef.current.value ==="Select")
            alert("Pls select a country")

    }
    render() {
        var optionArray = this.state.countryName.map((item,index) => {
            return (
                <option key={index} defaultValue={index===0}>{item}</option>
            )
        })
        return (
            <div className="container-fluid">
                <div className="row">

                </div>
                <div className="row ">
                    <div className="col-6 offset-3 bg-primary text-white">
                        <form>
                            <div>
                                <label>Username</label>
                                <input type="text" required className="form-control m-2"
                                ref={this.usernameRef} />
                            </div>
                            <div>
                                <label>Password</label>
                                <input type="password" required className="form-control m-2"
                                ref={this.passwordRef}/>
                            </div>
                            <div>
                                <label>Confirm Password</label>
                                <input type="password" required className="form-control m-2" />
                            </div>
                            <div>
                                <label>Country</label>
                                <select className="form-control m-2"
                                ref={this.countryRef}>
                                    {optionArray}
                                </select>
                            </div>
                            <div>
                                <input type="submit" value="Register"
                                className="btn btn-success m-2"
                                onClick={this.registerEventHandler} />

                                <input type="reset" value="Cancel"
                                className="btn btn-success m-2"
                                 />
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

export default Register