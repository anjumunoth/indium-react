import React from 'react'

class Cart extends React.Component
{
    
    render()
    {
        console.log("Cart Arr",this.props.cartArr)
        return(
            <React.Fragment>
                <h1> Cart Component</h1>
            </React.Fragment>
        )
    }
}

export default Cart