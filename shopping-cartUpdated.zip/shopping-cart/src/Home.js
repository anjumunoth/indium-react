import React from 'react'
import {Route} from "react-router-dom"
import Cart from './Cart'
import Employee from './Employee'
import ProductSearch from './ProductSearch'
import Login from "./Login"
import Register from "./Register"

class Home extends React.Component
{
    render()
    {
        return(
            <React.Fragment>
                <Route path="/products" component={ProductSearch}></Route>
                <Route path="/employee" component={Employee}></Route>
                <Route path="/cart" component={Cart}></Route>
                <Route path="/login" component={Login}></Route>
                <Route path="/register" component={Register}></Route>
            </React.Fragment>
        )
    }
}

export default Home