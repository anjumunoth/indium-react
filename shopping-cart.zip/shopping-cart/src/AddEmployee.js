import React from "react"

class AddEmployee extends React.Component
{
    constructor()
    {
        super();//parent class constructor
        this.cancelEmpEventhandler=this.cancelEmpEventhandler.bind(this);
        this.state={empId:"",empName:"",salary:"",location:"",errMessage:""}
    }
    confirmAddEmployeeEventHandler=(event) =>{
        // event -- button ; value : Confirm Add Employee
        if(this.state.salary <=0)
        {
            this.setState({errMessage:"Salary cannot be less than or equal to zero"});
            return;
        }
        
        var tempEmp={
            empId:this.state.empId,
            empName:this.state.empName,
            salary:this.state.salary,
            location:this.state.location
        }
        console.log(event)
        console.log("New User",tempEmp)
        this.props.onAddConfirm(tempEmp);

    }
    cancelEmpEventhandler()
    {
        alert("Cancel button clicked");
    }
    changeEmpIdEventHandler=(event)=>{
        console.log(event.target.value)
        this.setState({empId:event.target.value})
        //update the state and call the render method implicitly
    }
    changeEmpNameEventHandler=(event)=>{
        this.setState({empName:event.target.value})
    }
    changeEmpSalaryEventHandler=(event)=>{
        this.setState({salary:event.target.value})
        //setState -- object merges with the existing state; 
    }
    changeLocationEventHandler=(event)=>{
        this.setState({location:event.target.value})
    }
    render()
    {
        return (
            <div className="container-fluid">
                <h1>Add Employee Component</h1>
                <form className="col-8 offset-2">
                    <div className="row">
                        <label className="form-label col-4">
                        Employee Id
                        </label>
                        <input type="text" 
                        className="form-control col-8"
                        onChange={this.changeEmpIdEventHandler}
                         />
                    </div>
                    <div className="row">
                        <label className="form-label col-4">
                        Employee Name
                        </label>
                        <input type="text" className="form-control col-8" 
                        onChange={this.changeEmpNameEventHandler}/>
                    </div>
                    <div className="row">
                        <label className="form-label col-4">
                        Employee Salary
                        </label>
                        <input type="text" className="form-control col-8"
                        onChange={this.changeEmpSalaryEventHandler} />
                    </div>
                    <div className="row">
                        <label className="form-label col-4">
                        Location
                        </label>
                        <input type="text" className="form-control col-8"
                        onChange={this.changeLocationEventHandler} />
                    </div>
                    <div className="row">
                        <input type="button" value="Confirm Add Employee" 
                        className="btn btn-success" 
                        onClick={this.confirmAddEmployeeEventHandler} />

                        <input type="button" value="Cancel"
                        className="btn btn-danger"
                        onClick={this.cancelEmpEventhandler} />


                    </div>


                </form>
                <p>Employee Id :{this.state.empId}</p>
                <p>Employee Name :{this.state.empName}</p>
                {this.state.errMessage != "" && <h3 style={{color:"red"}}>{this.state.errMessage}</h3>}
            </div>
        )

    }
}

export default AddEmployee

// state -- local mutable data of teh component