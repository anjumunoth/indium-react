import React from 'react'

class AddToCart extends React.Component {
    constructor(props) {
        super(props)
        this.state = { quantityPurchased: 1, selectedProduct: this.props.selectedProduct }
    }
    changeQuantity = (str1) => {
        if (str1 == "dec") {
            if (this.state.quantityPurchased > 1) {
                this.setState((prevState) => {
                    return { quantityPurchased: prevState.quantityPurchased - 1 }
                })
            }
        }
        else {
            if (this.state.quantityPurchased < this.props.selectedProduct.quantity) {
                this.setState((prevState) => {
                    return { quantityPurchased: prevState.quantityPurchased + 1 }
                })
            }

        }
    }
    confirmBuyEventhandler=()=>{
        var tempObj={...this.state.selectedProduct,quantityPurchased:this.state.quantityPurchased};
        this.props.buyProduct(tempObj);
    }
    static getDerivedStateFromProps(newProps, prevState) {
        // cannot use "this"; state  -- no; props --no   
        // whatever this function returns, it will become my new state
        if (newProps.selectedProduct.productId != prevState.selectedProduct.productId) {
            // reinitialisation of quantityPurchased =1
            return ({ ...prevState, quantityPurchased: 1, selectedProduct: newProps.selectedProduct })
        }
        else {
            return prevState;
        }

    }
    render() {
        console.log("Props", this.props)
        var item = this.props.selectedProduct;
        return (
            <React.Fragment>
                <h1> Add To cart Component</h1>
                <div className="col-4">
                    <div className="card bg-warning text-primary m-5" style={{ width: "18rem" }}>
                        <div>
                            <img className="card-img-top img-responsive" src={item.imageUrl} alt={item.productName} style={{ width: "100%", height: "200px" }} />
                        </div>
                        <div className="card-body">
                            <h2 className="card-title text-center">{item.productName}</h2>
                            <p className="card-text">{item.description} </p>
                            <p className="card-text"> Price : Rs.{item.price}</p>
                            <p className="card-text">Quantity :{item.quantity}</p>
                            <input type="button" value="-" className="btn btn-primary m-3" onClick={this.changeQuantity.bind(this, "dec")} />
                            {this.state.quantityPurchased}
                            <input type="button" value="+" className="btn btn-primary m-3" onClick={this.changeQuantity.bind(this, "inc")} />
                            <br/>
                            <input type="button" value="Confirm Buy" className="btn btn-primary" onClick={this.confirmBuyEventhandler} />
                        </div>
                    </div>

                </div>
            </React.Fragment>

        )
    }
}

export default AddToCart;