import React from 'react'

class Cart extends React.Component
{
    render()
    {
        return(
            <React.Fragment>
                <h1> Cart Component</h1>
            </React.Fragment>
        )
    }
}

export default Cart