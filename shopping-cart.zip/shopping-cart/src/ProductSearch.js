import React from 'react'
import ProductFilter from './ProductFilter';

class ProductSearch extends React.Component {
    constructor() {
        super()
        this.state = { filterText: "", filterField: "productName", 
        showPriceCategory: false,
        priceText:{start:0,end:500} }
    }
    filterTextEventHandler = (event) => {
        this.setState({ filterText: event.target.value });
    }
    filterFieldChangehandler = (p1) => {
        //alert(p1);
        this.setState({ filterField: p1 })
        if (p1 === "price") {
            this.setState({ showPriceCategory: true });
        }
        else {
            this.setState({ showPriceCategory: false })
        }
    }
    setPriceFilterEventHandler=(indexPosition)=>{
        var filterArrValue=[{start:0,end:500},{start:501,end:5000},{start:5001,end:10000}]
        this.setState({priceText:filterArrValue[indexPosition]});
    }
    render() {
        return (
            <div>
                <h1>Search for product details</h1>
                <div>
                    <input type="radio" name="filterField" defaultChecked value="productName"
                        onClick={this.filterFieldChangehandler.bind(this, "productName")}
                    /> Product Name
                <input type="radio" name="filterField" value="description"
                        onClick={this.filterFieldChangehandler.bind(this, "description")}
                    /> Product Description
                <input type="radio" name="filterField" value="price"
                        onClick={this.filterFieldChangehandler.bind(this, "price")}
                    /> Price
                <br />
                    {this.state.showPriceCategory ?
                        <div>
                            <br /><input type="radio" name="priceFilter" 
                            defaultChecked onClick={this.setPriceFilterEventHandler.bind(this,0)} /> 0 to 500
                            
                            <br /><input type="radio" name="priceFilter" 
                            onClick={this.setPriceFilterEventHandler.bind(this,1)}/> 501 to 5000
                            
                            <br /><input type="radio" name="priceFilter" 
                            onClick={this.setPriceFilterEventHandler.bind(this,2)}/> 5001 to 10000
                        </div>
                        :
                        <input type="text" placeholder="Enter text to filter" onChange={this.filterTextEventHandler} />

                    }
                </div>
                <ProductFilter
                    filterText={this.state.filterText}
                    filterField={this.state.filterField}
                    priceText={this.state.priceText}
                ></ProductFilter>
            </div>
        )
    }

}
export default ProductSearch