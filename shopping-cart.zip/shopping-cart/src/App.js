import React from 'react'
import './App.css';
import logo from "./logo.png"
import Employee from "./Employee"
import Register from './Register';
import Login from './Login';
import ProductSearch from './ProductSearch';
import Cart from "./Cart"

class App extends React.Component {
  constructor()
  {
    super()
    this.state={showCart:false,showEmployee:true,showLogin:false,showRegister:false,showProductSearch:false}
  }
  showComponent=(componentName)=>{
    if(componentName ==="emp")
    {
      this.setState({showCart:false,showEmployee:true,showLogin:false,showRegister:false,showProductSearch:false})
    }
    if(componentName ==="register")
    {
      this.setState({showCart:false,showEmployee:false,showLogin:false,showRegister:true,showProductSearch:false})
    }
    if(componentName==="login")
    {
      this.setState({showCart:false,showEmployee:false,showLogin:true,showRegister:false,showProductSearch:false})
    }
    if(componentName==="productSearch")
    {
      this.setState({showCart:false,showProductSearch:true,showEmployee:false,showLogin:false,showRegister:false})
    }
    if(componentName ==="cart")
    {
      this.setState({showCart:true,showProductSearch:false,showEmployee:false,showLogin:false,showRegister:false})
    }

  }
  render() {
    return (
      <div>
        <input type="button" value="Show Employee" onClick={this.showComponent.bind(this,"emp")} />
        <input type="button" value="Show Register" onClick={this.showComponent.bind(this,"register")} />
        <input type="button" value="Show Login" onClick={this.showComponent.bind(this,"login")} />
        <input type="button" value="Show Product Search" onClick={this.showComponent.bind(this,"productSearch")} />
        <input type="button" value="Show Cart" onClick={this.showComponent.bind(this,"cart")} />
        {this.state.showEmployee && <Employee></Employee> }
        {this.state.showRegister &&<Register></Register> }
        {this.state.showLogin && <Login></Login>}
        {this.state.showProductSearch && <ProductSearch></ProductSearch>}
        {this.state.showCart && <Cart></Cart>}
      </div>
    );
  }
}

export default App;
