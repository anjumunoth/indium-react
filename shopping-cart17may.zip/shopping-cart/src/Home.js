import React from 'react'
import { Route, Switch } from "react-router-dom"
import Cart from './Cart'
import Employee from './Employee'
import ProductSearch from './ProductSearch'
import Login from "./Login"
import Register from "./Register"

class Home extends React.Component {
    constructor(props) {
        super(props)// base class constructor
        this.state = { cartArr: [] }
    }
    cartDataEventHandler = (cartData) => {
        var pos = this.state.cartArr.findIndex(item => item.productId == cartData.productId)
        if (pos >= 0) {
            var tempArr = [...this.state.cartArr]
            tempArr[pos].quantityPurchased += cartData.quantityPurchased
            this.setState({ cartArr: tempArr })

        }
        else {
            var tempArr = [...this.state.cartArr, cartData]
            this.setState({ cartArr: tempArr })
        }

    }
    render() {
        return (
            <React.Fragment>
                <Switch>
                    <Route path="/products">
                        <ProductSearch sendCartDataFromSearchToApp={this.cartDataEventHandler}></ProductSearch>
                    </Route>
                    <Route path="/employee" component={Employee}></Route>
                    <Route path="/cart" >
                        <Cart cartArr={this.state.cartArr}></Cart>
                    </Route>
                    <Route path="/login" component={Login}></Route>
                    <Route path="/register" component={Register}></Route>
                    <Route path="/" component={Employee} exact></Route>
                    <Route render={(props) => {
                        console.log(props);
                        return (<h1> Page not found</h1>)
                    }}></Route>
                </Switch>
            </React.Fragment>
        )
    }
}

export default Home