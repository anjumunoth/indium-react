import React, { Component } from 'react'
import AddToCart from './AddToCart'

class ProductFilter extends Component {
    constructor() {
        super()
        this.state = {showAddToCart:false,selectedProduct:{},cartArr:[],
            productArr: [
                { productId: 101, productName: "Iphone XR", description: " IPhone XR mobile from Apple", price: 2343, imageUrl: "./Images/iphone.jpg",quantity:11 },
                { productId: 102, productName: "One plus Nord", description: "One plus Nord mobile ", price: 4343, imageUrl: "./Images/oneplus.jpg",quantity:20 },
                { productId: 103, productName: "Samsung Note 9", description: "Samsung Note 9 mobile", price: 123, imageUrl: "./Images/samsung note.jpg",quantity:10 },
                { productId: 104, productName: "Vivo v 19", description: " Vivo v 19 mobile", price: 6754, imageUrl: "./Images/vivo.jpg",quantity:10 },
                { productId: 105, productName: "HTC Note", description: " Htc mobile with 16gb RAM", price: 123, imageUrl: "./Images/htc.jpg",quantity:5 },
                { productId: 106, productName: "Dell Laptop", description: "Dell Laptop Xps 14 inch", price: 453, imageUrl: "./Images/dell.jpg",quantity:11 },
                { productId: 107, productName: "Imac Desktop", description: "Imac desktop from Apple", price: 1212, imageUrl: "./Images/imac.jpg",quantity:101 },
                { productId: 108, productName: "Hp Spectra", description: " Hp Laptop  15 inch", price: 123, imageUrl: "./Images/hp.jpg",quantity:2},
                { productId: 109, productName: "Lenovo notebook", description: "Lenovo laptop 14 inch", price: 65, imageUrl: "./Images/lenovo.jpg",quantity:6 },
                { productId: 110, productName: "Asus Convertible", description: "Asus convertible laptop", price: 2345, imageUrl: "./Images/asus.jpg",quantity:16 },

            ]
        }
    }
    addToCartEventHandler=(selectedObj)=>{
        this.setState({showAddToCart:true,selectedProduct:selectedObj})
    }
    buyProductEventHandler=(objPurchased)=>{
        console.log("Product Purchased",objPurchased)
        // changes in the array
        var pos=this.state.productArr.findIndex(item => item.productId == objPurchased.productId)
        var tempArr=[...this.state.productArr];
        tempArr[pos].quantity-=objPurchased.quantityPurchased
        this.setState({productArr:tempArr,showAddToCart:false})
        this.props.sendCartDataFromFilterToSearch(objPurchased)

    }
    render() {
        console.log("In child component product filter", this.props)
        var { filterText, filterField,priceText } = this.props;
        if (filterField == "price") {
            var tempArr = this.state.productArr.filter(item => {
                if ((item.price >= priceText.start) && (item.price <= priceText.end))
                    return true;
            })
        }
        else
        if (filterField == "description" || filterField == "productName") {
                if (filterText !== "") {
                    if (filterField === "description") {
                        var tempArr = this.state.productArr.filter(item => {
                            if (item.description.toLowerCase().includes(filterText.toLowerCase())) {
                                return true
                            }
                        })
                    }
                    else
                        if (filterField === "productName") {
                            var tempArr = this.state.productArr.filter(item => {
                                if (item.productName.toLowerCase().includes(filterText.toLowerCase())) {
                                    return true
                                }
                            })
                        }

                }
                else {
                    var tempArr = this.state.productArr;
                }
            }
            
        var divArray = tempArr.map((item) => {
            return (
                <div className="col-4">
                    <div className="card bg-warning text-primary m-5" style={{ width: "18rem" }}>
                        <div>
                            <img className="card-img-top img-responsive" src={item.imageUrl} alt={item.productName} style={{ width: "100%", height: "200px" }} />
                        </div>
                        <div className="card-body">
                            <h2 className="card-title text-center">{item.productName}</h2>
                            <p className="card-text">{item.description} </p>
                            <p className="card-text"> Price : Rs.{item.price}</p>
                            <p className="card-text">Quantity :{item.quantity}</p>
                            <input type="button" value="AddToCart" className="btn btn-primary"
                            onClick={this.addToCartEventHandler.bind(this,item)}/>
                        </div>
                    </div>

                </div>
            )
        })
        return (
            <React.Fragment>
                <div className="container">
                    <div className="row">
                        {divArray}
                    </div>
                    {divArray.length == 0 && <h1> No items match ur search text</h1>}
                </div>
                <div>
                    {this.state.showAddToCart && <AddToCart buyProduct={this.buyProductEventHandler} selectedProduct={this.state.selectedProduct}></AddToCart>}
                </div>
            </React.Fragment>
        )
    }
}

export default ProductFilter