import React from 'react'

class Login extends React.Component
{
    constructor()
    {
        super();
        this.state = {errMsg:[],
         
        };
        this.emailRef=React.createRef();
        this.passwordRef=React.createRef();
    }

    LoginEventHandler=(event)=>{
       // event.preventDefault();
        var errArray =[];
        var email=this.emailRef.current.value;
        if(!isNaN(parseInt(email)))
        {
            errArray.push("Email Should be a string");
            console.log('err',errArray);
        }
        
        if(errArray.length>0)
        {
            this.setState({errMsg:errArray});
            return ;
        }
        else
        {
            this.props.history.push("/")
        }
    }


    render()
    {
        return(
            <div className="signup-form">
    <form>
		<h2>Sign In</h2>
        <div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<i className="fa fa-paper-plane"></i>
					</span>                    
				</div>
				<input type="email" className="form-control"  placeholder="Email Address" required ref={this.emailRef}/>
			</div>
        </div>
		<div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<i className="fa fa-lock"></i>
					</span>                    
				</div>
				<input type="password" className="form-control"  placeholder="Password" required ref={this.passwordRef}/>
			</div>
        </div>
        <div className="form-group">
        <input type="submit" value= "Login" className="btn btn-primary btn-lg"  onClick={this.LoginEventHandler}/>
        </div>
        </form>
        {this.state.errMsg.length>0 && <ul>
                   {this.state.errMsg.map((item,index)=>{
                       return(
                       <li key={index}>{item}</li>
                       )
                   })}
                   </ul>}
        </div>
        )
    }
}
export default Login