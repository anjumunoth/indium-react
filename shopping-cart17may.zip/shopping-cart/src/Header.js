import React from 'react'
import logo from "./logo.jpg"
import "./Header.css"
function Header(props)
{
    return(
        <React.Fragment>
            <div className="container;fluid bg-primary text-warning">
                <div className="row align-items-center">
                <img src={logo} alt="Indium logo" className="col-4 img-responsive"/>
                <h2 className="col-7 text-center fontStyle48">Indium Software </h2>
                </div>
            </div>
        </React.Fragment>
    )
} 

export default Header;

//functional component -- no lifecycle methods; no state
// functional -- static data