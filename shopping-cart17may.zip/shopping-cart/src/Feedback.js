import React from 'react'

class Feedback extends React.Component
{
    render()
    {
        return(
            <React.Fragment>
                <h1>Feedback Component </h1>
            </React.Fragment>
            
        )
    }
}
export default Feedback;