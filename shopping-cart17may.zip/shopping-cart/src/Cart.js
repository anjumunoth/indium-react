import React from 'react'
import PropTypes from "prop-types";

class Cart extends React.Component
{
    
    render()
    {
        var trArr=this.props.cartArr.map(item=>{
            return(
                <tr key={item.productId}>
                    <td>{item.productName}</td>
                    <td>{item.price}</td>
                    <td>{item.quantityPurchased}</td>
                    <td>{item.price * item.quantityPurchased}</td>
                    </tr>

            )
        })
        console.log("Cart Arr",this.props.cartArr)
        return(
            <React.Fragment>
                <h1> Cart Component</h1>
                {this.props.cartArr.length ===0 && <h1> No items added to the cart</h1>}
                <table className="table bg-primary text-warning">
                    <thead>
                        <tr>
                            <td>Product Name</td>
                            <td>Price</td>
                            <td>Quantity</td>
                            <td>Total</td>
                        </tr>
                    </thead>
                    <tbody>
                        {trArr}
                    </tbody>

                </table>
            </React.Fragment>
        )
    }
}
// static var; Classname.staticvarname; outside the class
// props -- data type; required or optional
Cart.propTypes={
    cartArr: PropTypes.array
}

// default values for the props if the props are not coming in
 Cart.defaultProps={
    cartArr:[]
} 
export default Cart
// var i={rules:[false,true]};