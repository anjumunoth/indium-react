import React from 'react'
import Login from './Login';
import  './Register.css'

class Register extends React.Component {
    constructor() {
        super()
        this.state = {
            countryName: ["India", "Australia", "Malaysia", "Singapore", "Phillipines"],
            errMsg:[],
            showLogin:false
        };
        this.emailRef=React.createRef();
        this.usernameRef=React.createRef();
        this.passwordRef=React.createRef();
        this.confirmPasswordRef=React.createRef();
        this.countryRef=React.createRef();
        this.checkBoxRef=React.createRef();

    }
    registerEventHandler=(event)=>{
       // event.preventDefault();
       this.setState({errMsg:[]});
        var errArray =[];
        var eName=this.usernameRef.current.value;
        var email=this.emailRef.current.value;
        var password=this.passwordRef.current.value;
        var confirmPassword=this.confirmPasswordRef.current.value;
        var checkBox=this.checkBoxRef.current.value;
        alert(password)
        alert(confirmPassword)
      // console.log('checkbox',checkBox);
        if(!isNaN(parseInt(eName)))
        {
            errArray.push("User Name Should be a string");
            console.log('err',errArray);
        }
        if(!isNaN(parseInt(email)))
        {
            errArray.push("Email Should be a string");
            console.log('err',errArray);
        }
         if(password !==confirmPassword)
         {
            errArray.push("Both Password and ConfirmPassword Should be same");
         }
         if(!checkBox)
         {
            errArray.push("Please Confirm the terms and conditions");
         }
        if(errArray.length>0)
        {
            this.setState({errMsg:errArray});
            event.preventDefault();
            return false ;
        }
        else
        {
           //send the details to store in the server
           // navigate to the /
           this.props.history.push("/")
        }
       
    }
    LoginEventHandler=()=>
    {
        this.setState({showLogin:true})
    }
    render() {
        console.log(this.props)//empty  data from the parent
        var optionArray = this.state.countryName.map((item,index) => {
            return (
                <option key={index}>{item}</option>
            )
        })
        return (
            <div className="signup-form">
    <form>
		<h2>Sign Up</h2>
		<p>Please fill in this form to create an account!</p>
        <div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<span className="fa fa-user"></span>
					</span>                    
				</div>
				<input type="text" className="form-control"  placeholder="Username" required ref={this.usernameRef}/>
			</div>
        </div>
        <div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<i className="fa fa-paper-plane"></i>
					</span>                    
				</div>
				<input type="email" className="form-control"  placeholder="Email Address" required ref={this.emailRef}/>
			</div>
        </div>
		<div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<i className="fa fa-lock"></i>
					</span>                    
				</div>
				<input type="password" className="form-control"  placeholder="Password" required ref={this.passwordRef}/>
			</div>
        </div>
		<div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
						<i className="fa fa-lock"></i>
						<i className="fa fa-check"></i>
					</span>                    
				</div>
				<input type="password" className="form-control"  placeholder="Confirm Password" required ref={this.confirmPasswordRef}/>
			</div>
        </div>
        <div className="form-group">
			<div className="input-group">
				<div className="input-group-prepend">
					<span className="input-group-text">
                    <i className="fa fa-flag" aria-hidden="true"></i>
					</span>                    
				</div>
                <select className="form-control" placeholder="Country"
                                ref={this.countryRef}>
                                    {optionArray}
                                </select>
            </div>
        </div>
        
        <div className="form-group">
			<label className="form-check-label"><input type="checkbox" required ref={this.checkBoxRef}/> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
		</div>
		<div className="form-group">
        <input type="submit" className="btn btn-primary btn-lg"  onClick={this.registerEventHandler}/>
        </div>
        
    </form>
	<div className="text-center">Already have an account?  <input type="submit"  value="Login" className="btn btn-primary btn-lg"  onClick={this.LoginEventHandler}/></div>
    {this.state.errMsg.length>0 && <ul>
                   {this.state.errMsg.map((item,index)=>{
                       return(
                       <li key={index}>{item}</li>
                       )
                   })}
                   </ul>}
                   {this.state.showLogin && <Login></Login> }
</div>


        )
    }
}

export default Register
