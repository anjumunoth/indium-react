/* Create a component EditEmployee
Basis of a flag do the conditional rendering
*/

import React from 'react'

class EditEmployee extends React.Component
{   
    constructor()
    {
        super()
        this.empNameRef=React.createRef();
        this.salaryRef=React.createRef();
        this.locationRef=React.createRef();
    }

    confirmEditEventHandler=()=>{
        var tempObj={
            empId:this.props.selectedEmp.empId,
            empName:this.empNameRef.current.value,
            salary:this.salaryRef.current.value,
            location:this.locationRef.current.value
        }
        console.log("Edited emp",tempObj)
        this.props.onEditConfirm(tempObj);
    }
    render()
    {
        console.log(" selectedEmp ",this.props.selectedEmp)
        var {selectedEmp}=this.props;//selectedEmp=this.props.selectedEmp
        return(
            <div className="container bg-info text-primary">
                <h1>Edit Employee Component</h1>
                <form className="col-8 offset-2">
                    <div className="row ">
                        <label className="col-4">Employee Id</label>
                        <label className="col-8">{selectedEmp.empId}</label>
                    </div>
                    <div className="row">
                        <label className="col-4">Employee Name</label>
                        <input className="col-8 form-control" type="text" 
                        defaultValue ={selectedEmp.empName}
                        ref={this.empNameRef}
                        />
                    </div>
                    <div className="row">
                        <label className="col-4">Employee Salary</label>
                        <input className="col-8 form-control" 
                        type="text" defaultValue ={selectedEmp.salary}
                        ref={this.salaryRef}/>
                    </div>
                    <div className="row">
                        <label className="col-4">Location</label>
                        <input className="col-8 
                        form-control" type="text" 
                        defaultValue ={selectedEmp.location}
                        ref={this.locationRef}/>
                    </div>
                    <div className="row">
                        <input type="button" value="Confirm details" 
                        className="btn btn-success"
                        onClick={this.confirmEditEventHandler}/>
                    </div>
                </form>
               
            </div>
        )
    }
}

export default EditEmployee

// parent -- > child using props
