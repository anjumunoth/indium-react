import React from 'react'

class AboutUs extends React.Component
{
    render()
    {
        return(
            <React.Fragment>
                <h1>About Us </h1>
            </React.Fragment>
            
        )
    }
}

export default AboutUs