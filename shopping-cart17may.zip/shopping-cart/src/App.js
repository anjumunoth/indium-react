import React from 'react'
import './App.css';
import Header from "./Header"
import Footer from "./Footer"
import Menu from "./Menu"
import { BrowserRouter } from "react-router-dom"
import Home from "./Home"
// npm install --save react-router-dom

class App extends React.Component {

  render() {
    return (
      <div>
        <Header></Header>
        <BrowserRouter>
            <Menu></Menu>
            <Home ></Home>
        </BrowserRouter>
        <Footer></Footer>
      </div>
    );
  }
}

export default App;
/*
   <input type="button" value="Show Employee" onClick={this.showComponent.bind(this,"emp")} />
        <input type="button" value="Show Register" onClick={this.showComponent.bind(this,"register")} />
        <input type="button" value="Show Login" onClick={this.showComponent.bind(this,"login")} />
        <input type="button" value="Show Product Search" onClick={this.showComponent.bind(this,"productSearch")} />
        <input type="button" value="Show Cart" onClick={this.showComponent.bind(this,"cart")} />
        {this.state.showEmployee && <Employee></Employee> }
        {this.state.showRegister &&<Register></Register> }
        {this.state.showLogin && <Login></Login>}
        {this.state.showProductSearch && }
        {this.state.showCart && <Cart cartArr={this.state.cartArr}></Cart>}

*/